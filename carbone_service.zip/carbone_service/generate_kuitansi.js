const carbone = require('carbone');
const fs = require('fs');
const path = require('path');

const generateKuitansi = (data, callback) => {
  console.error('Received data:', JSON.stringify(data));
  const templatePath = path.join(__dirname, '..', 'KUITANSI_FINAL.docx');
  
  carbone.render(templatePath, data, (err, result) => {
    if (err) {
      console.error('Carbone render error:', err);
      return callback(err);
    }
    
    const outputPath = path.join(__dirname, '..', `temp_kuitansi_${data.nomor}.docx`);
    fs.writeFile(outputPath, result, (err) => {
        if (err) {
          console.error('File write error:', err);
          return callback(err);
        }
        console.error('File generated successfully');
        callback(null, outputPath);
      });
    });
  };
  
  // Read data from stdin
  let inputData = '';
  process.stdin.on('data', (chunk) => {
    inputData += chunk;
  });
  
  process.stdin.on('end', () => {
    try {
      const data = JSON.parse(inputData);
      generateKuitansi(data, (err, outputPath) => {
        if (err) {
          console.error('Error in generateKuitansi:', err);
          console.log(JSON.stringify({ error: err.message }));
        } else {
          console.log(JSON.stringify({ success: true, file: outputPath }));
        }
      });
    } catch (error) {
      console.error('Error parsing input:', error);
      console.log(JSON.stringify({ error: 'Invalid input data' }));
    }
  });